void solve(unsigned char (*problem)[9][9])
{

}
